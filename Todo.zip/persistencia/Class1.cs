﻿using System;

namespace persistencia
{
    public class Class1
    {
    }
}
