﻿using System;
using dominio;

namespace consola
{
    class Program
    {
        static void Main(string[] args)
        {
            Usuario persona = new Usuario();
            persona.Nombre = "ColombiaFPS";

            Console.WriteLine("El nombre de la persona es: " + persona.Nombre);
        }
    }
}
