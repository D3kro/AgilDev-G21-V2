﻿using System;

namespace dominio
{
    public class OrdenDeTrabajo
    {
        public string Fecha {get; set;}
        public string Status {get; set;}
    }
}
