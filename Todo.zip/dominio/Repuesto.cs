﻿using System;

namespace dominio
{
    public class Repuesto
    {
        public string Descripción {get; set;}
        public string Cantidad {get; set;}
    }
}
