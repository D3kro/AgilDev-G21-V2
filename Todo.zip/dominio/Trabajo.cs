﻿using System;

namespace dominio
{
    public class Trabajo
    {
        public string Descripción {get; set;}
    }
}
