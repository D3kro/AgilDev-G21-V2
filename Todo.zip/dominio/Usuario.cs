﻿using System;

namespace dominio
{
    public class Usuario
    {
        public string DNI {get; set;}
        public string Correo {get; set;}
        public string Nombre {get; set;}
        public string Apellido {get; set;}
        public int Teléfono {get; set;}
        public int Tipo_Usuario {get; set;}
        public string Contraseña {get; set;}
    }
}
